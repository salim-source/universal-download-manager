# DropDown - Media Downloader

**Paste. Choose. Download.**
Paste a public video or media link, pick a quality, and download it. Works with publicly accessible media only.

## Run it (4 steps)

1. Install **Node.js 18 or newer** (the LTS version) from https://nodejs.org
2. Open this folder in **VS Code** (File > Open Folder).
3. Open the terminal in VS Code (Terminal > New Terminal) and run:

   ```
   npm install
   ```

   This installs everything for the root, `server` and `client` and downloads the downloader engine (yt-dlp) automatically. It can take a few minutes.

4. Start the app:

   ```
   npm run dev
   ```

Then open **http://localhost:5173** in your browser. (The API runs at http://localhost:4000 - you don't need to open it.)

Stop the app with `Ctrl + C` in the terminal.

## Environment variables

**None are required.** There are no API keys. The app starts fine without a `.env` file.

If you want to change a setting (port, max file size, ...), copy `server/.env.example` to `server/.env` and edit it.

## What works

- Direct video/audio links (.mp4, .webm, .mp3, ...) - always
- YouTube, Facebook public videos and many other public sites - through yt-dlp
- Some sites will not work (private, login-required, DRM, live streams, sites that block automated access). DropDown tells you clearly when that happens.

## Handy commands

| Command | What it does |
| --- | --- |
| `npm run dev` | Start server + website for development |
| `npm run dev:lan` | Same, but reachable from your phone on the same Wi-Fi (use the "Network" address Vite prints) |
| `npm run update:ytdlp` | Update the downloader engine (do this if a site stops working) |
| `npm start` | Build the website and serve everything from http://localhost:4000 |

## Folders

- `client/` - React + Vite + Tailwind website
- `server/` - Node + Express API (`routes/`, `services/`, `utils/`)

## Troubleshooting

- **"Can't reach the DropDown server"** - make sure `npm run dev` is still running and nothing else uses port 4000.
- **yt-dlp not found** - run `npm run update:ytdlp`, then restart. Direct links still work without it.
- **A YouTube/Facebook link fails** - those sites change often and sometimes block automated access. Run `npm run update:ytdlp` and try again later.

## Please note

Only download media you own or have permission to save, and respect each website's terms. DropDown does not bypass DRM, logins, private content, paywalls, or age/region restrictions. Downloaded files are kept on the server only while your download is being prepared and are deleted right after.
