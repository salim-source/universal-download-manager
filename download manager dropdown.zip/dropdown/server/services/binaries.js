import fs from 'node:fs';
import path from 'node:path';
import { config, SERVER_ROOT } from '../utils/config.js';
import { runProcess } from '../utils/proc.js';

let ytdlpCache = null;
let ffmpegCache = null;

async function works(cmd, args) {
  try {
    const res = await runProcess(cmd, args, { timeoutMs: 15000, collectStdout: true, maxStdoutBytes: 100000 });
    return res.code === 0 ? res.stdout.trim().split('\n')[0] : null;
  } catch {
    return null;
  }
}

/** Finds yt-dlp: YTDLP_PATH -> server/bin -> PATH. Returns { path, version } or null. */
export async function getYtdlp() {
  if (ytdlpCache) return ytdlpCache;
  const local = path.join(SERVER_ROOT, 'bin', process.platform === 'win32' ? 'yt-dlp.exe' : 'yt-dlp');
  const candidates = [config.ytdlpPath, fs.existsSync(local) ? local : '', 'yt-dlp', 'yt-dlp.exe'].filter(Boolean);
  for (const candidate of candidates) {
    const version = await works(candidate, ['--version']);
    if (version) {
      ytdlpCache = { path: candidate, version };
      return ytdlpCache;
    }
  }
  return null; // not cached, so installing it later works without a restart
}

/** Finds ffmpeg: FFMPEG_PATH -> ffmpeg-static package -> PATH. Returns { path } or null. */
export async function getFfmpeg() {
  if (ffmpegCache) return ffmpegCache;
  const candidates = [config.ffmpegPath];
  try {
    const mod = await import('ffmpeg-static');
    if (mod.default) candidates.push(mod.default);
  } catch { /* optional dependency not installed */ }
  candidates.push('ffmpeg');
  for (const candidate of candidates.filter(Boolean)) {
    if (await works(candidate, ['-version'])) {
      ffmpegCache = { path: candidate };
      return ffmpegCache;
    }
  }
  return null;
}
