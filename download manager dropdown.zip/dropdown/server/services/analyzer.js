import { AppError } from '../utils/errors.js';
import { assertPublicUrl, detectSource } from '../utils/urlValidator.js';
import { probeDirect } from './directMedia.js';
import { analyzeWithYtdlp } from './ytdlp.js';

/** Validate the URL, decide which engine can handle it, return metadata for the UI. */
export async function analyzeUrl(rawUrl) {
  const url = await assertPublicUrl(rawUrl);
  const source = detectSource(url);

  if (source.key === 'direct') return probeDirect(url);

  try {
    return await analyzeWithYtdlp(url, source);
  } catch (err) {
    // Unknown site: maybe it is a plain media file without a file extension in the link.
    const fallbackWorthTrying = source.key === 'other' &&
      err instanceof AppError && ['UNSUPPORTED', 'EXTRACTION_FAILED', 'ENGINE_MISSING'].includes(err.code);
    if (!fallbackWorthTrying) throw err;
    try {
      return await probeDirect(url);
    } catch (probeErr) {
      if (probeErr instanceof AppError && ['UNSUPPORTED', 'EXTRACTION_FAILED'].includes(probeErr.code)) {
        throw err.code === 'ENGINE_MISSING' ? err : new AppError('UNSUPPORTED');
      }
      throw probeErr;
    }
  }
}
