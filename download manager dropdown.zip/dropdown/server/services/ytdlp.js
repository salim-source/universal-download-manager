import fs from 'node:fs/promises';
import path from 'node:path';
import { config } from '../utils/config.js';
import { AppError, mapYtdlpError } from '../utils/errors.js';
import { runProcess } from '../utils/proc.js';
import { safeFilename } from '../utils/files.js';
import { getFfmpeg, getYtdlp } from './binaries.js';
import { buildFormatOptions, ytdlpFormatArgs } from './formats.js';

const clean = (text, max = 200) =>
  String(text || '').replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, max);

function pickThumbnail(info) {
  const candidates = [info.thumbnail, ...(Array.isArray(info.thumbnails) ? [...info.thumbnails].reverse().map((t) => t?.url) : [])];
  const found = candidates.find((u) => typeof u === 'string' && /^https?:\/\//i.test(u));
  return found || null;
}

function prettySource(info, fallback) {
  const key = info.extractor_key;
  if (!key || key === 'Generic') return fallback;
  if (key === 'Youtube') return 'YouTube';
  return key.replace(/([a-z])([A-Z])/g, '$1 $2');
}

/** Ask yt-dlp for metadata only (nothing is downloaded). */
export async function analyzeWithYtdlp(url, source) {
  const ytdlp = await getYtdlp();
  if (!ytdlp) throw new AppError('ENGINE_MISSING');
  const ffmpeg = await getFfmpeg();

  const args = [
    '--ignore-config', '--dump-single-json', '--no-playlist', '--no-warnings',
    '--socket-timeout', '15', '--', url.href,
  ];
  const res = await runProcess(ytdlp.path, args, {
    timeoutMs: config.analyzeTimeoutMs, collectStdout: true,
  });

  if (res.timedOut) throw new AppError('TIMEOUT');
  if (res.code !== 0) {
    console.warn('[yt-dlp analyze]', res.stderr.slice(-400).trim());
    throw mapYtdlpError(res.stderr, 'EXTRACTION_FAILED');
  }

  let info;
  try {
    info = JSON.parse(res.stdout);
  } catch {
    throw new AppError('EXTRACTION_FAILED');
  }

  if (info._type === 'playlist' || Array.isArray(info.entries)) throw new AppError('PLAYLIST');
  if (info.is_live || info.live_status === 'is_live' || info.live_status === 'is_upcoming') throw new AppError('LIVE');

  const raw = Array.isArray(info.formats) ? info.formats : [];
  if (raw.length && raw.every((f) => f.has_drm === true)) throw new AppError('DRM');

  const formats = buildFormatOptions(raw, Boolean(ffmpeg));
  const duration = Number(info.duration);
  return {
    title: clean(info.title) || 'Untitled media',
    thumbnail: pickThumbnail(info),
    duration: Number.isFinite(duration) && duration > 0 ? Math.round(duration) : null,
    source: prettySource(info, source.label),
    sourceKey: source.key,
    url: url.href,
    formats,
    note: ffmpeg ? null : 'ffmpeg was not found, so only ready-made files (usually up to 720p) are offered.',
  };
}

/**
 * Download with yt-dlp into job.dir. Reports REAL progress parsed from yt-dlp.
 * hooks: { update(partial), signal }
 */
export async function downloadWithYtdlp(job, hooks) {
  const ytdlp = await getYtdlp();
  if (!ytdlp) throw new AppError('ENGINE_MISSING');
  const ffmpeg = await getFfmpeg();
  const formatArgs = ytdlpFormatArgs(job.formatId, Boolean(ffmpeg));

  const args = [
    '--ignore-config', '--no-playlist', '--no-warnings', '--newline', '--no-colors',
    '--socket-timeout', '20', '--retries', '3', '--concurrent-fragments', '4',
    '--max-filesize', String(config.maxFileBytes),
    '--progress-template',
    'download:DD|%(progress.status)s|%(progress.downloaded_bytes)s|%(progress.total_bytes)s|%(progress.total_bytes_estimate)s|%(progress.speed)s|%(progress.eta)s|%(progress.fragment_index)s|%(progress.fragment_count)s|%(info.format_id)s|%(info.title)s',
    '-o', path.join(job.dir, 'media.%(ext)s'),
    ...formatArgs,
  ];
  if (ffmpeg && ffmpeg.path !== 'ffmpeg') args.push('--ffmpeg-location', ffmpeg.path);
  args.push('--', job.url);

  const ctl = new AbortController();
  hooks.signal.addEventListener('abort', () => ctl.abort(), { once: true });

  let finishedStreams = 0;
  let finishedBytes = 0;
  let title = '';
  const num = (v) => {
    const n = Number(v);
    return Number.isFinite(n) && v !== '' ? n : null;
  };
  let tooLarge = false;

  const onLine = (line) => {
    if (line.startsWith('DD|')) {
      const p = line.split('|');
      const status = p[1];
      const downloaded = num(p[2]);
      const total = num(p[3]) ?? num(p[4]);
      const speed = num(p[5]);
      const eta = num(p[6]);
      const fragIndex = num(p[7]);
      const fragCount = num(p[8]);
      const parts = (p[9] || '').split('+').length;
      title = title || p.slice(10).join('|');

      let fraction = null;
      if (total && downloaded !== null) fraction = Math.min(1, downloaded / total);
      else if (fragCount && fragIndex !== null) fraction = Math.min(1, fragIndex / fragCount);

      if (status === 'finished') {
        finishedStreams += 1;
        finishedBytes += downloaded || 0;
        hooks.update({ status: 'downloading', percent: Math.min(100, Math.round((finishedStreams / parts) * 100)), part: Math.min(finishedStreams + 1, parts), parts });
        return;
      }
      if (total && finishedBytes + total > config.maxFileBytes) {
        tooLarge = true;
        ctl.abort();
        return;
      }
      hooks.update({
        status: 'downloading',
        percent: fraction === null ? null : Math.min(100, Math.round(((finishedStreams + fraction) / parts) * 100)),
        downloadedBytes: downloaded,
        totalBytes: total,
        speed,
        eta,
        part: Math.min(finishedStreams + 1, parts),
        parts,
      });
    } else if (/^\[(Merger|ExtractAudio|VideoRemuxer|FixupM3u8|Fixup\w*)\]/.test(line)) {
      hooks.update({ status: 'processing', percent: null, speed: null, eta: null });
    }
  };

  hooks.update({ status: 'fetching' });
  const res = await runProcess(ytdlp.path, args, {
    timeoutMs: config.downloadTimeoutMs, signal: ctl.signal, onStdoutLine: onLine,
  });

  if (tooLarge) throw new AppError('FILE_TOO_LARGE');
  if (hooks.signal.aborted) throw new AppError('CANCELLED');
  if (res.timedOut) throw new AppError('TIMEOUT');
  if (res.code !== 0) {
    console.warn('[yt-dlp download]', res.stderr.slice(-400).trim());
    throw mapYtdlpError(res.stderr, 'DOWNLOAD_FAILED');
  }

  const files = (await fs.readdir(job.dir)).filter(
    (n) => n.startsWith('media.') && !/\.(part|ytdl|temp|tmp)$/i.test(n),
  );
  if (!files.length) throw new AppError('DOWNLOAD_FAILED');
  let best = null;
  for (const name of files) {
    const stat = await fs.stat(path.join(job.dir, name));
    if (!best || stat.size > best.size) best = { name, size: stat.size };
  }
  if (best.size > config.maxFileBytes) throw new AppError('FILE_TOO_LARGE');

  const ext = path.extname(best.name).slice(1);
  return { filePath: path.join(job.dir, best.name), size: best.size, filename: safeFilename(clean(title), ext) };
}
