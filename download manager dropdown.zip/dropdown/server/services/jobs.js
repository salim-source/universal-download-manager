import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import { config } from '../utils/config.js';
import { AppError, toPublicError } from '../utils/errors.js';
import { ensureTempDir, removeDir } from '../utils/files.js';
import { assertPublicUrl } from '../utils/urlValidator.js';
import { downloadDirect } from './directMedia.js';
import { assertFormatId } from './formats.js';
import { downloadWithYtdlp } from './ytdlp.js';

const jobs = new Map();
const ACTIVE = new Set(['queued', 'fetching', 'downloading', 'processing']);

export const isJobId = (id) => /^[0-9a-f-]{36}$/.test(id);
export const getJob = (id) => jobs.get(id);

export function publicJob(job) {
  return {
    id: job.id,
    status: job.status,
    percent: job.percent,
    downloadedBytes: job.downloadedBytes,
    totalBytes: job.totalBytes,
    speed: job.speed,
    eta: job.eta,
    part: job.part,
    parts: job.parts,
    filename: job.status === 'completed' ? job.filename : null,
    size: job.status === 'completed' ? job.size : null,
    error: job.error || null,
  };
}

/** Validate everything again (never trust the browser), then start the job in the background. */
export async function createJob({ url, formatId }) {
  const parsed = await assertPublicUrl(url);
  assertFormatId(formatId);

  const running = [...jobs.values()].filter((j) => ACTIVE.has(j.status)).length;
  if (running >= config.maxConcurrentJobs) throw new AppError('BUSY');

  await ensureTempDir();
  const id = crypto.randomUUID();
  const job = {
    id, url: parsed.href, formatId,
    dir: path.join(config.tempDir, id),
    status: 'queued', percent: null,
    downloadedBytes: null, totalBytes: null, speed: null, eta: null, part: 1, parts: 1,
    filePath: null, filename: null, size: null, error: null,
    createdAt: Date.now(), controller: new AbortController(),
  };
  await fs.mkdir(job.dir, { recursive: true });
  jobs.set(id, job);
  run(job); // runs in the background; errors are handled inside
  return job;
}

async function run(job) {
  const hooks = {
    signal: job.controller.signal,
    update: (partial) => {
      if (job.status === 'cancelled' || job.status === 'failed') return;
      Object.assign(job, partial);
    },
  };
  try {
    const engine = job.formatId === 'direct' ? downloadDirect : downloadWithYtdlp;
    const result = await engine(job, hooks);
    if (job.status === 'cancelled') return;
    Object.assign(job, { status: 'completed', percent: 100, speed: null, eta: null, ...result });
  } catch (err) {
    if (job.status === 'cancelled') return;
    if (!(err instanceof AppError)) console.error('[job error]', err);
    job.status = 'failed';
    job.error = toPublicError(err);
    await removeDir(job.dir);
  }
}

export async function cancelJob(job) {
  job.status = 'cancelled';
  job.controller.abort();
  await discardJob(job);
}

export async function discardJob(job) {
  jobs.delete(job.id);
  await removeDir(job.dir);
}

/** Remove expired jobs and their temporary files so the disk never fills up. */
export function startCleanupLoop() {
  const timer = setInterval(() => {
    const now = Date.now();
    for (const job of jobs.values()) {
      if (now - job.createdAt > config.jobTtlMs && !ACTIVE.has(job.status)) discardJob(job);
      else if (now - job.createdAt > config.downloadTimeoutMs + config.jobTtlMs) cancelJob(job);
    }
  }, 60 * 1000);
  timer.unref();
  return timer;
}

export function shutdownJobs() {
  for (const job of jobs.values()) job.controller.abort();
}
