import { AppError } from '../utils/errors.js';

export const TIERS = [2160, 1440, 1080, 720, 480, 360];

// The ONLY format ids the server accepts. Anything else is rejected, so nothing a user sends
// can ever reach yt-dlp as an option.
export const FORMAT_ID_RE = /^(best|direct|(mp4|webm)-(2160|1440|1080|720|480|360)|audio-(m4a|mp3))$/;

export function assertFormatId(formatId) {
  if (typeof formatId !== 'string' || !FORMAT_ID_RE.test(formatId)) throw new AppError('INVALID_FORMAT');
  return formatId;
}

/** yt-dlp arguments for one of our preset format ids. */
export function ytdlpFormatArgs(formatId, hasFfmpeg) {
  assertFormatId(formatId);
  if (formatId === 'direct') throw new AppError('INVALID_FORMAT');

  if (formatId === 'best') {
    return hasFfmpeg ? ['-f', 'bv*+ba/b', '--merge-output-format', 'mp4'] : ['-f', 'b'];
  }

  if (formatId === 'audio-m4a') {
    return hasFfmpeg
      ? ['-f', 'ba[ext=m4a]/ba/b', '-x', '--audio-format', 'm4a']
      : ['-f', 'ba[ext=m4a]/ba'];
  }
  if (formatId === 'audio-mp3') {
    if (!hasFfmpeg) throw new AppError('INVALID_FORMAT', "MP3 needs ffmpeg, which isn't available on this server. Choose M4A instead.");
    return ['-f', 'ba/b', '-x', '--audio-format', 'mp3', '--audio-quality', '0'];
  }

  const [container, heightText] = formatId.split('-');
  const h = Number.parseInt(heightText, 10);
  if (container === 'mp4') {
    return hasFfmpeg
      ? [
          '-f',
          `bv*[height<=${h}][ext=mp4]+ba[ext=m4a]/bv*[height<=${h}][ext=mp4]+ba/b[height<=${h}][ext=mp4]/bv*[height<=${h}]+ba/b[height<=${h}]`,
          '--merge-output-format', 'mp4',
        ]
      : ['-f', `b[height<=${h}][ext=mp4]`];
  }
  return hasFfmpeg
    ? ['-f', `bv*[height<=${h}][ext=webm]+ba[ext=webm]/b[height<=${h}][ext=webm]`, '--merge-output-format', 'webm']
    : ['-f', `b[height<=${h}][ext=webm]`];
}

const hasCodec = (c) => c && c !== 'none';

/** Turn yt-dlp's raw format list into the simple options shown in the UI. */
export function buildFormatOptions(rawFormats, hasFfmpeg) {
  const usable = (rawFormats || []).filter(
    (f) => f && f.has_drm !== true && (hasCodec(f.vcodec) || hasCodec(f.acodec)),
  );
  const video = usable.filter((f) => hasCodec(f.vcodec) && Number(f.height) > 0);
  // Without ffmpeg we can only use files that already contain video AND audio.
  const pool = hasFfmpeg ? video : video.filter((f) => hasCodec(f.acodec));
  const audioCapable = usable.filter((f) => hasCodec(f.acodec));
  const audioOnly = usable.filter((f) => hasCodec(f.acodec) && !hasCodec(f.vcodec));

  const formats = [{ id: 'best', kind: 'best', ext: 'auto', height: null, label: 'Best available' }];

  for (const h of TIERS) {
    for (const ext of ['mp4', 'webm']) {
      const found = pool.some((f) => f.ext === ext && Number(f.height) >= h * 0.95);
      if (found) formats.push({ id: `${ext}-${h}`, kind: 'video', ext, height: h, label: `${h}p` });
    }
  }

  if (audioOnly.length || (hasFfmpeg && audioCapable.length)) {
    formats.push({ id: 'audio-m4a', kind: 'audio', ext: 'm4a', height: null, label: 'Audio only' });
    if (hasFfmpeg) formats.push({ id: 'audio-mp3', kind: 'audio', ext: 'mp3', height: null, label: 'Audio only' });
  }
  return formats;
}
