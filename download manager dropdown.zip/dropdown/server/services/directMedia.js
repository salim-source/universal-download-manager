import fs from 'node:fs';
import path from 'node:path';
import { Readable, Transform } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import { config } from '../utils/config.js';
import { AppError } from '../utils/errors.js';
import { safeFilename } from '../utils/files.js';
import { DIRECT_EXTENSIONS, assertPublicUrl, urlExtension } from '../utils/urlValidator.js';

const MIME_EXT = {
  'video/mp4': 'mp4', 'video/webm': 'webm', 'video/quicktime': 'mov', 'video/x-matroska': 'mkv',
  'video/ogg': 'ogv', 'video/x-m4v': 'm4v', 'audio/mpeg': 'mp3', 'audio/mp4': 'm4a', 'audio/x-m4a': 'm4a',
  'audio/ogg': 'ogg', 'audio/wav': 'wav', 'audio/x-wav': 'wav', 'audio/webm': 'weba',
  'audio/aac': 'aac', 'audio/flac': 'flac', 'audio/opus': 'opus',
};
const HEADERS = { 'User-Agent': 'DropDown/1.0 (+local media downloader)', Accept: '*/*' };

/** fetch() that re-validates every redirect target (so a redirect can't point at a private address). */
async function safeFetch(href, init, signal, maxRedirects = 5) {
  let current = href;
  for (let i = 0; i <= maxRedirects; i += 1) {
    const url = await assertPublicUrl(current);
    let res;
    try {
      res = await fetch(url.href, { ...init, redirect: 'manual', signal, headers: { ...HEADERS, ...(init.headers || {}) } });
    } catch (err) {
      if (signal?.aborted) throw err;
      throw new AppError('NETWORK');
    }
    if ([301, 302, 303, 307, 308].includes(res.status)) {
      const loc = res.headers.get('location');
      res.body?.cancel?.().catch(() => {});
      if (!loc) throw new AppError('EXTRACTION_FAILED');
      current = new URL(loc, url).href;
      continue;
    }
    return { res, url };
  }
  throw new AppError('EXTRACTION_FAILED');
}

function httpError(status) {
  if (status === 401) return new AppError('LOGIN_REQUIRED');
  if (status === 403) return new AppError('PRIVATE_MEDIA');
  if (status === 404 || status === 410) return new AppError('NOT_FOUND');
  return new AppError('EXTRACTION_FAILED');
}

function describe(res, url) {
  const type = (res.headers.get('content-type') || '').split(';')[0].trim().toLowerCase();
  const urlExt = urlExtension(url);
  const hasMediaExt = DIRECT_EXTENSIONS.has(urlExt);
  const isMedia = type.startsWith('video/') || type.startsWith('audio/') ||
    ((type === 'application/octet-stream' || type === 'binary/octet-stream' || !type) && hasMediaExt);
  const ext = hasMediaExt ? urlExt : MIME_EXT[type] || 'mp4';
  const isAudio = type.startsWith('audio/') || ['mp3', 'm4a', 'ogg', 'oga', 'wav', 'aac', 'flac', 'weba', 'opus'].includes(ext);
  const range = res.headers.get('content-range');
  const size = Number(range ? range.split('/')[1] : res.headers.get('content-length'));
  return { isMedia, ext, isAudio, size: Number.isFinite(size) && size > 0 ? size : null, type };
}

function titleFromUrl(url) {
  const last = url.pathname.split('/').filter(Boolean).pop() || url.hostname;
  let name = last;
  try { name = decodeURIComponent(last); } catch { /* keep raw */ }
  return name.replace(/\.[a-z0-9]{2,5}$/i, '').replace(/[_+]+/g, ' ').trim().slice(0, 200) || url.hostname;
}

function withTimeout(ms, parent) {
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), ms);
  if (parent) parent.addEventListener('abort', () => ctl.abort(), { once: true });
  return { signal: ctl.signal, done: () => clearTimeout(timer) };
}

/** Check that a URL is a publicly reachable media file. Returns analyze-style metadata. */
export async function probeDirect(url) {
  const t = withTimeout(15000);
  try {
    let result = await safeFetch(url.href, { method: 'HEAD' }, t.signal).catch((e) => (e instanceof AppError && e.code !== 'NETWORK' ? Promise.reject(e) : null));
    if (!result || !result.res.ok) {
      if (result?.res && [401, 403, 404, 410].includes(result.res.status) && result.res.status !== 403) throw httpError(result.res.status);
      result = await safeFetch(url.href, { method: 'GET', headers: { Range: 'bytes=0-0' } }, t.signal);
      result.res.body?.cancel?.().catch(() => {});
    }
    const { res, url: finalUrl } = result;
    if (!res.ok) throw httpError(res.status);
    const d = describe(res, finalUrl);
    if (!d.isMedia) throw new AppError('UNSUPPORTED');
    return {
      title: titleFromUrl(finalUrl),
      thumbnail: null,
      duration: null,
      source: finalUrl.hostname.replace(/^www\./, ''),
      sourceKey: 'direct',
      url: url.href,
      formats: [{
        id: 'direct', kind: 'direct', ext: d.ext, height: null, label: 'Original file', filesize: d.size,
      }],
      note: null,
    };
  } catch (err) {
    if (err instanceof AppError) throw err;
    if (t.signal.aborted) throw new AppError('TIMEOUT');
    throw new AppError('NETWORK');
  } finally {
    t.done();
  }
}

/** Stream a direct media file to disk with a hard size limit and real progress. */
export async function downloadDirect(job, hooks) {
  hooks.update({ status: 'fetching' });
  const t = withTimeout(config.downloadTimeoutMs, hooks.signal);
  try {
    const { res, url } = await safeFetch(job.url, { method: 'GET' }, t.signal);
    if (!res.ok) throw httpError(res.status);
    const d = describe(res, url);
    if (!d.isMedia) throw new AppError('UNSUPPORTED');
    const total = Number(res.headers.get('content-length')) || null;
    if (total && total > config.maxFileBytes) throw new AppError('FILE_TOO_LARGE');
    if (!res.body) throw new AppError('DOWNLOAD_FAILED');

    const dest = path.join(job.dir, `media.${d.ext}`);
    let received = 0;
    let lastTick = Date.now();
    let lastBytes = 0;
    let speed = null;

    const counter = new Transform({
      transform(chunk, _enc, cb) {
        received += chunk.length;
        if (received > config.maxFileBytes) return cb(new AppError('FILE_TOO_LARGE'));
        const now = Date.now();
        if (now - lastTick >= 500) {
          speed = ((received - lastBytes) / (now - lastTick)) * 1000;
          lastTick = now;
          lastBytes = received;
          hooks.update({
            status: 'downloading',
            percent: total ? Math.min(100, Math.round((received / total) * 100)) : null,
            downloadedBytes: received,
            totalBytes: total,
            speed,
            eta: total && speed ? Math.round((total - received) / speed) : null,
            part: 1, parts: 1,
          });
        }
        return cb(null, chunk);
      },
    });

    hooks.update({ status: 'downloading', percent: total ? 0 : null, totalBytes: total, part: 1, parts: 1 });
    await pipeline(Readable.fromWeb(res.body), counter, fs.createWriteStream(dest), { signal: t.signal });

    return {
      filePath: dest,
      size: received,
      filename: safeFilename(titleFromUrl(url), d.ext),
    };
  } catch (err) {
    if (err instanceof AppError) throw err;
    if (hooks.signal.aborted) throw new AppError('CANCELLED');
    if (t.signal.aborted) throw new AppError('TIMEOUT');
    if (err?.cause instanceof AppError) throw err.cause;
    throw new AppError('DOWNLOAD_FAILED');
  } finally {
    t.done();
  }
}
