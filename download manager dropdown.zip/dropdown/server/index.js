import cors from 'cors';
import express from 'express';
import rateLimit from 'express-rate-limit';
import helmet from 'helmet';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import analyzeRoutes from './routes/analyze.js';
import downloadRoutes from './routes/download.js';
import healthRoutes from './routes/health.js';
import { getFfmpeg, getYtdlp } from './services/binaries.js';
import { shutdownJobs, startCleanupLoop } from './services/jobs.js';
import { config } from './utils/config.js';
import { AppError, messageFor, statusFor, toPublicError } from './utils/errors.js';
import { ensureTempDir, wipeTempDir } from './utils/files.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();

app.disable('x-powered-by');
if (config.trustProxy) app.set('trust proxy', 1);

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", 'data:', 'https:'], // thumbnails come from the video's own site
      connectSrc: ["'self'"],
      objectSrc: ["'none'"],
      frameAncestors: ["'none'"],
      upgradeInsecureRequests: null, // this app runs on plain http://localhost
    },
  },
  strictTransportSecurity: false,
  crossOriginResourcePolicy: { policy: 'same-site' },
}));

app.use(cors({
  origin(origin, callback) {
    // No Origin header = same-origin request, curl, etc.
    if (!origin || config.clientOrigins.includes(origin)) return callback(null, true);
    return callback(null, false);
  },
  methods: ['GET', 'POST', 'DELETE'],
  maxAge: 600,
}));

app.use(express.json({ limit: '10kb' }));
app.use('/api', (_req, res, next) => {
  res.setHeader('Cache-Control', 'no-store');
  next();
});

const limitHandler = (_req, _res, next) => next(new AppError('RATE_LIMITED'));
const limiter = (windowMs, limit) => rateLimit({ windowMs, limit, standardHeaders: 'draft-7', legacyHeaders: false, handler: limitHandler });

app.use('/api/analyze', limiter(60 * 1000, config.analyzeLimitPerMin));
app.post('/api/download', limiter(10 * 60 * 1000, config.downloadLimitPer10Min));
app.use('/api/jobs', limiter(60 * 1000, 400)); // status polling

app.use('/api', healthRoutes);
app.use('/api', analyzeRoutes);
app.use('/api', downloadRoutes);
app.use('/api', (_req, _res, next) => next(new AppError('SERVER_ERROR', 'That API endpoint does not exist.')));

// Optional: serve the built website (npm run build, then npm start).
const dist = path.join(__dirname, '..', 'client', 'dist');
if (fs.existsSync(path.join(dist, 'index.html'))) {
  app.use(express.static(dist));
  app.get('*', (_req, res) => res.sendFile(path.join(dist, 'index.html')));
}

// eslint-disable-next-line no-unused-vars
app.use((err, _req, res, _next) => {
  if (err?.type === 'entity.parse.failed' || err?.type === 'entity.too.large') {
    return res.status(400).json({ error: { code: 'INVALID_URL', message: messageFor('INVALID_URL') } });
  }
  if (!(err instanceof AppError)) console.error('[server error]', err);
  return res.status(statusFor(err)).json({ error: toPublicError(err) });
});

await wipeTempDir();
await ensureTempDir();
const cleanupTimer = startCleanupLoop();

const server = app.listen(config.port, config.host, async () => {
  const [ytdlp, ffmpeg] = await Promise.all([getYtdlp(), getFfmpeg()]);
  console.log(`\nDropDown server running at http://${config.host}:${config.port}`);
  console.log(`  yt-dlp : ${ytdlp ? ytdlp.version : 'NOT FOUND (direct links still work - run "npm run update:ytdlp")'}`);
  console.log(`  ffmpeg : ${ffmpeg ? 'found' : 'not found (only ready-made files, usually up to 720p)'}`);
  console.log(`  limit  : ${config.maxFileSizeMB} MB per download\n`);
});

server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') console.error(`Port ${config.port} is already in use. Close the other program or set PORT in server/.env`);
  else console.error(err);
  process.exit(1);
});

async function shutdown() {
  clearInterval(cleanupTimer);
  shutdownJobs();
  await wipeTempDir().catch(() => {});
  process.exit(0);
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
