import { spawn } from 'node:child_process';

/**
 * Run a program WITHOUT a shell (arguments are passed as an array, so user input can never
 * be interpreted as a command). Supports timeout, abort signal and line-by-line stdout.
 */
export function runProcess(cmd, args, { timeoutMs = 60000, signal, onStdoutLine, collectStdout = false, maxStdoutBytes = 25_000_000 } = {}) {
  return new Promise((resolve, reject) => {
    let child;
    try {
      child = spawn(cmd, args, { shell: false, windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
    } catch (err) {
      reject(err);
      return;
    }

    let stdout = '';
    let stderr = '';
    let buffer = '';
    let timedOut = false;
    let aborted = false;
    let overflow = false;

    const kill = () => {
      try { child.kill('SIGKILL'); } catch { /* already gone */ }
    };
    const onAbort = () => { aborted = true; kill(); };
    const timer = setTimeout(() => { timedOut = true; kill(); }, timeoutMs);
    const cleanup = () => {
      clearTimeout(timer);
      if (signal) signal.removeEventListener('abort', onAbort);
    };

    if (signal) {
      if (signal.aborted) onAbort();
      else signal.addEventListener('abort', onAbort, { once: true });
    }

    child.stdout.setEncoding('utf8');
    child.stderr.setEncoding('utf8');

    child.stdout.on('data', (chunk) => {
      if (collectStdout) {
        if (stdout.length + chunk.length > maxStdoutBytes) { overflow = true; kill(); return; }
        stdout += chunk;
      }
      if (onStdoutLine) {
        buffer += chunk;
        let idx;
        while ((idx = buffer.indexOf('\n')) >= 0) {
          const line = buffer.slice(0, idx).replace(/\r$/, '');
          buffer = buffer.slice(idx + 1);
          try { onStdoutLine(line); } catch { /* ignore parser errors */ }
        }
      }
    });
    child.stderr.on('data', (chunk) => { stderr = (stderr + chunk).slice(-20000); });

    child.on('error', (err) => { cleanup(); reject(err); });
    child.on('close', (code) => {
      cleanup();
      resolve({ code, stdout, stderr, timedOut, aborted, overflow });
    });
  });
}
