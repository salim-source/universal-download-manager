import { config } from './config.js';

// code -> [HTTP status, friendly message]
const CATALOG = {
  EMPTY_URL: [400, 'Please paste a link first.'],
  INVALID_URL: [400, "That doesn't look like a valid link. Please paste a full URL starting with http:// or https://."],
  INVALID_FORMAT: [400, "That format isn't available. Please analyze the link again and pick one of the listed options."],
  HOST_NOT_FOUND: [400, "We couldn't find that website. Please check the link."],
  BLOCKED_URL: [400, "This kind of address can't be used. Please paste a public link."],
  UNSUPPORTED: [422, "Sorry, this website or media format isn't currently supported."],
  PLAYLIST: [422, "Playlists and channels aren't supported. Please paste a link to a single video."],
  LIVE: [422, "Live streams aren't supported. Try again once the video is available as a normal recording."],
  PRIVATE_MEDIA: [403, "This media is private, so it can't be downloaded. DropDown only works with publicly accessible media."],
  LOGIN_REQUIRED: [403, "This media needs a login, so it can't be downloaded. DropDown only works with publicly accessible media."],
  ACCESS_RESTRICTED: [403, "This media is restricted (for example by age, region or membership), so it can't be downloaded."],
  DRM: [403, "This media is DRM-protected, so it can't be downloaded."],
  BLOCKED_BY_SITE: [503, "This website is blocking automated access right now. Please try again later or use another public link."],
  NOT_FOUND: [404, "This media wasn't found. It may have been removed or the link may be wrong."],
  NETWORK: [502, 'A network problem got in the way. Please check your connection and try again.'],
  TIMEOUT: [504, 'This took too long and was stopped. Please try again or choose a lower quality.'],
  EXTRACTION_FAILED: [502, "Couldn't process this link. Please check the URL or try another publicly accessible video."],
  DOWNLOAD_FAILED: [502, 'The download failed. Please try again or choose another quality.'],
  ENGINE_MISSING: [503, "The downloader engine (yt-dlp) isn't installed on this server yet. Run \"npm run update:ytdlp\" in the project folder, then restart."],
  BUSY: [503, 'The server is busy with other downloads. Please wait a moment and try again.'],
  RATE_LIMITED: [429, 'Too many requests. Please wait a bit and try again.'],
  JOB_NOT_FOUND: [404, 'This download is no longer available. Please start it again.'],
  JOB_NOT_READY: [409, 'This download is not finished yet.'],
  CANCELLED: [499, 'The download was cancelled.'],
  SERVER_ERROR: [500, 'Something went wrong on the server. Please try again.'],
};

export class AppError extends Error {
  constructor(code, message) {
    const entry = CATALOG[code] || CATALOG.SERVER_ERROR;
    super(message || messageFor(code));
    this.name = 'AppError';
    this.code = CATALOG[code] ? code : 'SERVER_ERROR';
    this.status = entry[0];
  }
}

export function messageFor(code) {
  if (code === 'FILE_TOO_LARGE') {
    return `This file is larger than the ${config.maxFileSizeMB} MB limit, so it can't be downloaded here. Try a lower quality.`;
  }
  return (CATALOG[code] || CATALOG.SERVER_ERROR)[1];
}

export function toPublicError(err) {
  if (err instanceof AppError) return { code: err.code, message: err.message };
  return { code: 'SERVER_ERROR', message: messageFor('SERVER_ERROR') };
}

export function statusFor(err) {
  if (err instanceof AppError) return err.code === 'FILE_TOO_LARGE' ? 413 : err.status;
  return 500;
}

/** Turn yt-dlp's raw stderr into one of our friendly error codes. */
export function mapYtdlpError(stderr, fallback = 'EXTRACTION_FAILED') {
  const s = String(stderr || '').toLowerCase();
  if (!s) return new AppError(fallback);

  if (s.includes('unsupported url')) return new AppError('UNSUPPORTED');
  if (s.includes('drm')) return new AppError('DRM');
  if (s.includes('larger than max-filesize') || s.includes('file is larger')) return new AppError('FILE_TOO_LARGE');
  if (s.includes('not a bot') || s.includes('http error 429') || s.includes('too many requests')) {
    return new AppError('BLOCKED_BY_SITE');
  }
  if (s.includes('private video') || s.includes('this video is private') || s.includes('is private')) {
    return new AppError('PRIVATE_MEDIA');
  }
  if (
    s.includes('age-restricted') || s.includes('confirm your age') || s.includes('not available in your country') ||
    s.includes('geo restrict') || s.includes('geo-restrict') || s.includes('blocked it in your country')
  ) {
    return new AppError('ACCESS_RESTRICTED');
  }
  if (
    s.includes('sign in') || s.includes('log in') || s.includes('login') || s.includes('members-only') ||
    s.includes('members only') || s.includes('join this channel') || s.includes('requires authentication') ||
    s.includes('cookies') || s.includes('premium') || s.includes('rental') || s.includes('purchase')
  ) {
    return new AppError('LOGIN_REQUIRED');
  }
  if (s.includes('is live') || s.includes('live event') || s.includes('live stream')) return new AppError('LIVE');
  if (
    s.includes('video unavailable') || s.includes('http error 404') || s.includes('http error 410') ||
    s.includes('has been removed') || s.includes('does not exist') || s.includes('no longer available')
  ) {
    return new AppError('NOT_FOUND');
  }
  if (
    s.includes('timed out') || s.includes('connection') || s.includes('name or service not known') ||
    s.includes('temporary failure') || s.includes('getaddrinfo') || s.includes('network is unreachable')
  ) {
    return new AppError('NETWORK');
  }
  if (s.includes('requested format is not available')) return new AppError('INVALID_FORMAT',
    "This quality or format isn't available for this media. Please pick another option.");
  return new AppError(fallback);
}
