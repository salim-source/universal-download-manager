import fs from 'node:fs/promises';
import { config } from './config.js';

const RESERVED = /^(con|prn|aux|nul|com[1-9]|lpt[1-9])$/i;

/** Build a safe file name (no paths, no special characters, no reserved names). */
export function safeFilename(title, ext, fallback = 'media') {
  let base = String(title || '')
    .normalize('NFC')
    .replace(/[\u0000-\u001f\u007f<>:"/\\|?*]/g, ' ')
    .replace(/[\u200b-\u200f\u202a-\u202e\u2066-\u2069]/g, '')
    .replace(/\s+/g, ' ')
    .replace(/^[.\s]+|[.\s]+$/g, '');
  if (base.length > 100) base = base.slice(0, 100).trim();
  if (!base || RESERVED.test(base)) base = fallback;
  const cleanExt = String(ext || '').toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 5);
  return cleanExt ? `${base}.${cleanExt}` : base;
}

export async function ensureTempDir() {
  await fs.mkdir(config.tempDir, { recursive: true });
}

/** Empty the temp folder (used on start-up and shutdown so nothing is left behind). */
export async function wipeTempDir() {
  await fs.rm(config.tempDir, { recursive: true, force: true });
  await ensureTempDir();
}

export async function removeDir(dir) {
  if (!dir || !dir.startsWith(config.tempDir)) return; // never delete outside the temp folder
  await fs.rm(dir, { recursive: true, force: true }).catch(() => {});
}
