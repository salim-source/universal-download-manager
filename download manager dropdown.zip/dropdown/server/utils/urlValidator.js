import dns from 'node:dns/promises';
import net from 'node:net';
import { AppError } from './errors.js';
import { config } from './config.js';

const MAX_URL_LENGTH = 2048;

function ipv4ToParts(ip) {
  return ip.split('.').map((n) => Number.parseInt(n, 10));
}

function isPrivateV4(ip) {
  const [a, b, c] = ipv4ToParts(ip);
  return (
    a === 0 || a === 10 || a === 127 ||
    (a === 100 && b >= 64 && b <= 127) ||     // carrier-grade NAT
    (a === 169 && b === 254) ||               // link-local / cloud metadata
    (a === 172 && b >= 16 && b <= 31) ||
    (a === 192 && b === 168) ||
    (a === 192 && b === 0 && c === 0) ||
    (a === 198 && (b === 18 || b === 19)) ||
    a >= 224                                  // multicast + reserved
  );
}

function isPrivateV6(ip) {
  const s = ip.toLowerCase();
  if (s === '::' || s === '::1') return true;
  const dotted = s.match(/^::ffff:(\d+\.\d+\.\d+\.\d+)$/);
  if (dotted) return isPrivateV4(dotted[1]);
  const hex = s.match(/^::ffff:([0-9a-f]{1,4}):([0-9a-f]{1,4})$/);
  if (hex) {
    const hi = Number.parseInt(hex[1], 16);
    const lo = Number.parseInt(hex[2], 16);
    return isPrivateV4(`${hi >> 8}.${hi & 255}.${lo >> 8}.${lo & 255}`);
  }
  return (
    s.startsWith('fc') || s.startsWith('fd') ||                    // unique local
    /^fe[89ab]/.test(s) || s.startsWith('fec0') ||                 // link-local / site-local
    s.startsWith('ff')                                             // multicast
  );
}

export function isPrivateIp(ip) {
  const v = net.isIP(ip);
  if (v === 4) return isPrivateV4(ip);
  if (v === 6) return isPrivateV6(ip);
  return true; // unknown format: treat as unsafe
}

/**
 * Validates a user-supplied URL. Returns a URL object or throws an AppError.
 * Blocks non-http(s) schemes, embedded credentials and private/internal addresses (SSRF protection).
 */
export async function assertPublicUrl(raw) {
  if (typeof raw !== 'string') throw new AppError('INVALID_URL');
  const text = raw.trim();
  if (!text) throw new AppError('EMPTY_URL');
  if (text.length > MAX_URL_LENGTH || /[\s\u0000-\u001f\u007f]/.test(text)) throw new AppError('INVALID_URL');

  let url;
  try {
    url = new URL(text);
  } catch {
    throw new AppError('INVALID_URL');
  }
  if (url.protocol !== 'http:' && url.protocol !== 'https:') throw new AppError('INVALID_URL');
  if (url.username || url.password) throw new AppError('INVALID_URL');

  const host = url.hostname.replace(/^\[|\]$/g, '').toLowerCase().replace(/\.$/, '');
  if (!host) throw new AppError('INVALID_URL');

  if (config.allowPrivateUrls) return url;

  if (host === 'localhost' || host.endsWith('.localhost') || host.endsWith('.local') || host.endsWith('.internal')) {
    throw new AppError('BLOCKED_URL');
  }

  if (net.isIP(host)) {
    if (isPrivateIp(host)) throw new AppError('BLOCKED_URL');
    return url;
  }

  if (!host.includes('.')) throw new AppError('INVALID_URL');

  let addresses;
  try {
    addresses = await dns.lookup(host, { all: true });
  } catch {
    throw new AppError('HOST_NOT_FOUND');
  }
  if (!addresses.length || addresses.some((a) => isPrivateIp(a.address))) throw new AppError('BLOCKED_URL');
  return url;
}

const hostIs = (host, ...domains) => domains.some((d) => host === d || host.endsWith(`.${d}`));

export const DIRECT_EXTENSIONS = new Set([
  'mp4', 'webm', 'mov', 'm4v', 'mkv', 'ogv', 'mp3', 'm4a', 'ogg', 'oga', 'wav', 'aac', 'flac', 'weba', 'opus',
]);

export function urlExtension(url) {
  const match = url.pathname.toLowerCase().match(/\.([a-z0-9]{2,5})$/);
  return match ? match[1] : '';
}

/** Rough source detection used for the "Source" label and to pick a download engine. */
export function detectSource(url) {
  const host = url.hostname.toLowerCase().replace(/^www\./, '');
  if (hostIs(host, 'youtube.com', 'youtu.be', 'youtube-nocookie.com')) return { key: 'youtube', label: 'YouTube' };
  if (hostIs(host, 'facebook.com', 'fb.watch', 'fb.com')) return { key: 'facebook', label: 'Facebook' };
  if (DIRECT_EXTENSIONS.has(urlExtension(url))) return { key: 'direct', label: host };
  return { key: 'other', label: host };
}
