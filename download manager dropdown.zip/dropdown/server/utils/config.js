import dotenv from 'dotenv';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
export const SERVER_ROOT = path.join(__dirname, '..');

// A missing .env file is fine - every value below has a default.
dotenv.config({ path: path.join(SERVER_ROOT, '.env') });

const int = (value, fallback) => {
  const n = Number.parseInt(value, 10);
  return Number.isFinite(n) && n > 0 ? n : fallback;
};

const maxFileSizeMB = int(process.env.MAX_FILE_SIZE_MB, 500);

export const config = {
  port: int(process.env.PORT, 4000),
  host: process.env.HOST || '127.0.0.1',
  clientOrigins: (process.env.CLIENT_ORIGIN || 'http://localhost:5173,http://127.0.0.1:5173')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean),
  maxFileSizeMB,
  maxFileBytes: maxFileSizeMB * 1024 * 1024,
  downloadTimeoutMs: int(process.env.DOWNLOAD_TIMEOUT_MS, 15 * 60 * 1000),
  analyzeTimeoutMs: int(process.env.ANALYZE_TIMEOUT_MS, 45 * 1000),
  maxConcurrentJobs: int(process.env.MAX_CONCURRENT_DOWNLOADS, 3),
  jobTtlMs: int(process.env.JOB_TTL_MS, 10 * 60 * 1000),
  tempDir: process.env.TEMP_DIR || path.join(os.tmpdir(), 'dropdown-downloads'),
  ytdlpPath: process.env.YTDLP_PATH || '',
  ffmpegPath: process.env.FFMPEG_PATH || '',
  allowPrivateUrls: process.env.ALLOW_PRIVATE_URLS === 'true',
  trustProxy: process.env.TRUST_PROXY === 'true',
  analyzeLimitPerMin: int(process.env.RATE_LIMIT_ANALYZE_PER_MIN, 20),
  downloadLimitPer10Min: int(process.env.RATE_LIMIT_DOWNLOAD_PER_10MIN, 15),
  isProduction: process.env.NODE_ENV === 'production',
};
