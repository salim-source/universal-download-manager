// Downloads the official yt-dlp standalone program (no Python needed) into server/bin.
// It never fails the install: if the download doesn't work, DropDown still starts
// (direct MP4/audio links keep working) and you can run "npm run update:ytdlp" later.
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const binDir = path.join(__dirname, '..', 'bin');

function assetName() {
  const { platform, arch } = process;
  if (platform === 'win32') return { asset: 'yt-dlp.exe', local: 'yt-dlp.exe' };
  if (platform === 'darwin') return { asset: 'yt-dlp_macos', local: 'yt-dlp' };
  if (platform === 'linux') {
    return { asset: arch === 'arm64' ? 'yt-dlp_linux_aarch64' : 'yt-dlp_linux', local: 'yt-dlp' };
  }
  return null;
}

async function main() {
  if (process.env.YTDLP_PATH) {
    console.log('[yt-dlp] YTDLP_PATH is set - skipping download.');
    return;
  }
  const target = assetName();
  if (!target) {
    console.log('[yt-dlp] Unsupported platform. Install yt-dlp yourself and set YTDLP_PATH.');
    return;
  }
  const url = `https://github.com/yt-dlp/yt-dlp/releases/latest/download/${target.asset}`;
  console.log(`[yt-dlp] Downloading ${target.asset} ...`);

  const res = await fetch(url, { redirect: 'follow', headers: { 'User-Agent': 'DropDown-installer' } });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const bytes = Buffer.from(await res.arrayBuffer());
  if (bytes.length < 1_000_000) throw new Error('Downloaded file looks too small');

  await fs.mkdir(binDir, { recursive: true });
  const dest = path.join(binDir, target.local);
  const tmp = `${dest}.download`;
  await fs.writeFile(tmp, bytes, { mode: 0o755 });
  await fs.rename(tmp, dest);
  if (process.platform !== 'win32') await fs.chmod(dest, 0o755);
  console.log(`[yt-dlp] Installed to ${dest}`);
}

main().catch((err) => {
  console.warn(`[yt-dlp] Could not download automatically (${err.message}).`);
  console.warn('[yt-dlp] DropDown will still start. Try again later with: npm run update:ytdlp');
  process.exit(0);
});
