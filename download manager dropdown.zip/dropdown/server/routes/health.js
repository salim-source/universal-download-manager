import { Router } from 'express';
import { getFfmpeg, getYtdlp } from '../services/binaries.js';
import { config } from '../utils/config.js';
import { wrap } from '../utils/wrap.js';

const router = Router();

// GET /api/health
router.get('/health', wrap(async (_req, res) => {
  const [ytdlp, ffmpeg] = await Promise.all([getYtdlp(), getFfmpeg()]);
  res.json({
    ok: true,
    ytdlp: ytdlp ? ytdlp.version : null,
    ffmpeg: Boolean(ffmpeg),
    maxFileSizeMB: config.maxFileSizeMB,
  });
}));

export default router;
