import { Router } from 'express';
import { analyzeUrl } from '../services/analyzer.js';
import { wrap } from '../utils/wrap.js';

const router = Router();

// POST /api/analyze  { url }  ->  { title, thumbnail, duration, source, formats, ... }
router.post('/analyze', wrap(async (req, res) => {
  const result = await analyzeUrl(req.body?.url);
  res.json(result);
}));

export default router;
