import { Router } from 'express';
import { createJob, discardJob, cancelJob, getJob, isJobId, publicJob } from '../services/jobs.js';
import { AppError } from '../utils/errors.js';
import { wrap } from '../utils/wrap.js';

const router = Router();

function findJob(req) {
  const job = isJobId(req.params.id) ? getJob(req.params.id) : null;
  if (!job) throw new AppError('JOB_NOT_FOUND');
  return job;
}

// POST /api/download  { url, formatId }  ->  202 { jobId }
router.post('/download', wrap(async (req, res) => {
  const job = await createJob({ url: req.body?.url, formatId: req.body?.formatId });
  res.status(202).json({ jobId: job.id });
}));

// GET /api/jobs/:id  ->  live status and progress
router.get('/jobs/:id', wrap(async (req, res) => {
  res.json(publicJob(findJob(req)));
}));

// GET /api/jobs/:id/file  ->  the finished file (deleted from the server right after sending)
router.get('/jobs/:id/file', wrap(async (req, res, next) => {
  const job = findJob(req);
  if (job.status !== 'completed' || !job.filePath) throw new AppError('JOB_NOT_READY');
  job.status = 'sending';
  res.download(job.filePath, job.filename, (err) => {
    discardJob(job);
    if (err && !res.headersSent) next(new AppError('DOWNLOAD_FAILED'));
  });
}));

// DELETE /api/jobs/:id  ->  cancel and clean up
router.delete('/jobs/:id', wrap(async (req, res) => {
  const job = findJob(req);
  await cancelJob(job);
  res.status(204).end();
}));

export default router;
