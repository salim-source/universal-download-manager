import { formatDate } from '../lib/format.js';
import { ClockIcon, RefreshIcon, TrashIcon } from './Icons.jsx';

export default function History({ items, busy, onAgain, onRemove, onClear }) {
  return (
    <section id="history" aria-label="Download history" className="glass scroll-mt-6 p-5 sm:p-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2 className="flex items-center gap-2 text-lg font-semibold text-white">
          <ClockIcon className="h-5 w-5 text-accent-blue" /> History
        </h2>
        {items.length > 0 && (
          <button type="button" className="btn-ghost" onClick={() => { if (window.confirm('Clear your whole download history?')) onClear(); }}>
            <TrashIcon className="h-4 w-4" /> Clear history
          </button>
        )}
      </div>

      {items.length === 0 ? (
        <p className="mt-4 text-sm text-slate-400">
          Nothing here yet. Finished downloads show up here, so you can download them again in one click.
        </p>
      ) : (
        <ul className="mt-4 divide-y divide-white/5">
          {items.map((item) => (
            <li key={item.id} className="flex flex-col gap-3 py-3 sm:flex-row sm:items-center sm:justify-between">
              <div className="min-w-0">
                <p className="truncate font-medium text-slate-100" title={item.title}>{item.title}</p>
                <p className="mt-0.5 text-xs text-slate-500">
                  {item.source} &bull; {item.formatLabel} &bull; {formatDate(item.date)}
                </p>
              </div>
              <div className="flex shrink-0 gap-2">
                <button type="button" className="btn-ghost flex-1 sm:flex-none" disabled={busy} onClick={() => onAgain(item)}>
                  <RefreshIcon className="h-4 w-4" /> Download again
                </button>
                <button type="button" className="btn-ghost flex-1 sm:flex-none" onClick={() => onRemove(item.id)} aria-label={`Remove ${item.title} from history`}>
                  <TrashIcon className="h-4 w-4" /> Remove
                </button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
