import { formatBytes, formatEta } from '../lib/format.js';
import { AlertIcon, CheckIcon, XIcon } from './Icons.jsx';

const STEPS = [
  { phase: 'analyzing', label: 'Analyzing...', short: 'Analyze' },
  { phase: 'fetching', label: 'Fetching media...', short: 'Fetch' },
  { phase: 'downloading', label: 'Downloading...', short: 'Download' },
  { phase: 'preparing', label: 'Preparing download...', short: 'Prepare' },
  { phase: 'completed', label: 'Completed', short: 'Done' },
];

export default function ProgressCard({ phase, progress, error, onCancel, onDismiss }) {
  const failed = phase === 'failed';
  const done = phase === 'completed';
  const stageIndex = STEPS.findIndex((s) => s.phase === (failed ? error?.stage : phase));
  const current = failed ? Math.max(stageIndex, 0) : stageIndex;
  const percent = progress?.percent;
  const determinate = Number.isFinite(percent) && phase === 'downloading';
  const active = !failed && !done;

  const details = [];
  if (phase === 'downloading') {
    if (progress?.parts > 1) details.push(`Part ${progress.part} of ${progress.parts}`);
    if (progress?.downloadedBytes && progress?.totalBytes) details.push(`${formatBytes(progress.downloadedBytes)} of ${formatBytes(progress.totalBytes)}`);
    if (progress?.speed) details.push(`${formatBytes(progress.speed)}/s`);
    const eta = formatEta(progress?.eta);
    if (eta) details.push(eta);
  }

  return (
    <section aria-label="Download status" className="glass animate-rise mx-auto w-full max-w-3xl p-5 sm:p-6">
      <div className="flex items-start justify-between gap-4">
        <div className="min-w-0" role="status" aria-live="polite">
          <div className="flex items-center gap-2.5">
            {failed && <span className="text-rose-300"><AlertIcon /></span>}
            {done && <span className="flex h-6 w-6 items-center justify-center rounded-full bg-emerald-400/20 text-emerald-300"><CheckIcon className="h-4 w-4" /></span>}
            <h2 className={`text-lg font-semibold ${failed ? 'text-rose-200' : 'text-white'}`}>
              {failed ? 'Failed' : STEPS[current]?.label}
            </h2>
            {determinate && <span className="text-gradient text-lg font-bold">{percent}%</span>}
          </div>
          <p className={`mt-1 text-sm ${failed ? 'text-rose-200/90' : 'text-slate-400'}`}>
            {failed && error?.message}
            {done && 'Your download has started. Check your browser\u2019s downloads.'}
            {active && phase === 'analyzing' && 'Checking that this link is public and supported.'}
            {active && phase === 'fetching' && 'Connecting to the source.'}
            {active && phase === 'downloading' && (details.length ? details.join('  \u2022  ') : 'The source did not report a size, so progress can\u2019t be shown as a percentage.')}
            {active && phase === 'preparing' && 'Finishing the file. Your browser will save it next.'}
          </p>
        </div>
        {(active && phase !== 'analyzing') && (
          <button type="button" onClick={onCancel} className="btn-ghost shrink-0"><XIcon className="h-4 w-4" />Cancel</button>
        )}
        {(failed || done) && (
          <button type="button" onClick={onDismiss} className="btn-ghost shrink-0">{failed ? 'Dismiss' : 'Close'}</button>
        )}
      </div>

      {!failed && (
        <div
          className="relative mt-5 h-2.5 overflow-hidden rounded-full bg-white/10"
          role="progressbar"
          aria-valuemin={0}
          aria-valuemax={100}
          aria-valuenow={determinate ? percent : done ? 100 : undefined}
        >
          {determinate || done ? (
            <div
              className="h-full rounded-full bg-gradient-to-r from-accent-teal via-accent-blue to-accent-violet transition-[width] duration-500"
              style={{ width: `${done ? 100 : percent}%` }}
            />
          ) : (
            <div className="absolute inset-y-0 left-0 w-1/3 animate-slide rounded-full bg-gradient-to-r from-accent-teal via-accent-blue to-accent-violet" />
          )}
        </div>
      )}

      <ol className="mt-5 grid grid-cols-5 gap-2 text-center text-xs">
        {STEPS.map((s, i) => {
          const state = failed && i === current ? 'failed' : i < current || done ? 'done' : i === current ? 'active' : 'todo';
          const dot = {
            done: 'bg-emerald-400/90 text-ink-950',
            active: 'bg-accent-blue text-ink-950 ring-4 ring-accent-blue/20',
            failed: 'bg-rose-400 text-ink-950 ring-4 ring-rose-400/20',
            todo: 'bg-white/10 text-slate-500',
          }[state];
          return (
            <li key={s.phase} className="flex flex-col items-center gap-1.5">
              <span className={`flex h-6 w-6 items-center justify-center rounded-full text-[11px] font-bold ${dot}`}>
                {state === 'done' ? <CheckIcon className="h-3.5 w-3.5" /> : state === 'failed' ? '!' : i + 1}
              </span>
              <span className={`${state === 'todo' ? 'text-slate-600' : 'text-slate-300'} hidden sm:block`}>{s.short}</span>
            </li>
          );
        })}
      </ol>
    </section>
  );
}
