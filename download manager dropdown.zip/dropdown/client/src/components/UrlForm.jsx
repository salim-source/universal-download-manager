import { useState } from 'react';
import { PasteIcon, SearchIcon } from './Icons.jsx';

function validate(text) {
  const value = text.trim();
  if (!value) return 'Please paste a link first.';
  try {
    const u = new URL(value);
    if (u.protocol !== 'http:' && u.protocol !== 'https:') throw new Error('scheme');
    if (!u.hostname.includes('.') && !u.hostname.includes(':')) throw new Error('host');
  } catch {
    return "That doesn't look like a valid link. Please paste a full URL starting with http:// or https://.";
  }
  return null;
}

export default function UrlForm({ onAnalyze, busy, analyzing }) {
  const [value, setValue] = useState('');
  const [problem, setProblem] = useState(null);

  const submit = (e) => {
    e.preventDefault();
    const msg = validate(value);
    setProblem(msg);
    if (!msg) onAnalyze(value.trim());
  };

  const paste = async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text) { setValue(text.trim()); setProblem(null); }
    } catch {
      setProblem('Your browser blocked clipboard access. Please paste the link with Ctrl+V (or long-press) instead.');
    }
  };

  return (
    <form onSubmit={submit} noValidate className="mx-auto w-full max-w-3xl">
      <div className="rounded-[1.75rem] bg-gradient-to-r from-accent-teal/60 via-accent-blue/60 to-accent-violet/60 p-px shadow-glow">
        <div className="flex flex-col gap-3 rounded-[1.7rem] bg-ink-900/90 p-3 backdrop-blur-xl sm:flex-row sm:items-center sm:p-2.5">
          <label htmlFor="media-url" className="sr-only">Media URL</label>
          <div className="relative flex-1">
            <input
              id="media-url"
              type="url"
              inputMode="url"
              autoComplete="off"
              autoCapitalize="off"
              spellCheck="false"
              value={value}
              onChange={(e) => { setValue(e.target.value); if (problem) setProblem(null); }}
              placeholder="Paste video URL here..."
              aria-invalid={Boolean(problem)}
              aria-describedby={problem ? 'url-problem' : undefined}
              className="h-14 w-full rounded-2xl bg-transparent pl-5 pr-14 text-base text-white placeholder:text-slate-500 focus:outline-none sm:text-lg"
            />
            <button
              type="button"
              onClick={paste}
              disabled={busy}
              title="Paste from clipboard"
              aria-label="Paste from clipboard"
              className="absolute right-2 top-1/2 flex h-10 w-10 -translate-y-1/2 items-center justify-center rounded-xl text-slate-400 transition hover:bg-white/10 hover:text-white disabled:opacity-40"
            >
              <PasteIcon />
            </button>
          </div>
          <button type="submit" disabled={busy} className="btn-primary h-14 w-full sm:w-auto sm:px-8">
            <SearchIcon />
            {analyzing ? 'Analyzing...' : 'Analyze'}
          </button>
        </div>
      </div>
      {problem && (
        <p id="url-problem" role="alert" className="mt-3 px-2 text-sm text-rose-300">{problem}</p>
      )}
    </form>
  );
}
