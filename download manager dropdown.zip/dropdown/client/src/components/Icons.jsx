const base = { fill: 'none', stroke: 'currentColor', strokeWidth: 2, strokeLinecap: 'round', strokeLinejoin: 'round', 'aria-hidden': true };
const make = (d, extra) => function Icon({ className = 'h-5 w-5' }) {
  return <svg viewBox="0 0 24 24" className={className} {...base}>{d}{extra}</svg>;
};

export const DownloadIcon = make(<path d="M12 4v11m0 0-4.5-4.5M12 15l4.5-4.5M5 20h14" />);
export const SearchIcon = make(<><circle cx="11" cy="11" r="6.5" /><path d="m20 20-3.8-3.8" /></>);
export const PasteIcon = make(<><rect x="6" y="5" width="12" height="16" rx="2" /><path d="M9 5V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v1" /></>);
export const CheckIcon = make(<path d="m5 12.5 4.5 4.5L19 7.5" />);
export const XIcon = make(<path d="M6 6l12 12M18 6 6 18" />);
export const TrashIcon = make(<path d="M4 7h16M10 11v6M14 11v6M6 7l1 12a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1l1-12M9 7V4h6v3" />);
export const RefreshIcon = make(<path d="M20 11a8 8 0 1 0-2.3 5.7M20 5v6h-6" />);
export const ClockIcon = make(<><circle cx="12" cy="12" r="8.5" /><path d="M12 7.5V12l3 2" /></>);
export const FilmIcon = make(<><rect x="4" y="5" width="16" height="14" rx="2.5" /><path d="m10.5 9.5 4 2.5-4 2.5z" /></>);
export const AlertIcon = make(<><path d="M12 4 3 19h18z" /><path d="M12 10v4M12 17v.01" /></>);

export function Logo({ className = 'h-9 w-9' }) {
  return (
    <svg viewBox="0 0 32 32" className={className} aria-hidden="true">
      <defs>
        <linearGradient id="dd-logo" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#5eead4" />
          <stop offset=".55" stopColor="#60a5fa" />
          <stop offset="1" stopColor="#a78bfa" />
        </linearGradient>
      </defs>
      <rect width="32" height="32" rx="9" fill="#12152a" stroke="rgba(255,255,255,.12)" />
      <path d="M16 6v12m0 0-5-5m5 5 5-5M8 23h16" stroke="url(#dd-logo)" strokeWidth="2.8" strokeLinecap="round" strokeLinejoin="round" fill="none" />
    </svg>
  );
}
