import { Logo } from './Icons.jsx';

export default function Header() {
  return (
    <header className="flex items-center justify-between py-5 sm:py-7">
      <a href="/" className="flex items-center gap-3" aria-label="DropDown home">
        <Logo />
        <span className="flex flex-col leading-tight">
          <span className="text-lg font-bold tracking-tight text-white">DropDown</span>
          <span className="text-xs text-slate-400">Media Downloader</span>
        </span>
      </a>
      <a href="#history" className="btn-ghost">History</a>
    </header>
  );
}
