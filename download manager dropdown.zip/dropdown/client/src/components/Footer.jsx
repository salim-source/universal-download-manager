export default function Footer() {
  return (
    <footer className="py-8 text-center text-xs leading-relaxed text-slate-500">
      <p>
        DropDown only works with publicly accessible media. It does not bypass DRM, logins, private
        videos, age or region limits, or paywalls.
      </p>
      <p className="mt-1">Only download content you own or have permission to save, and follow each website's terms.</p>
    </footer>
  );
}
