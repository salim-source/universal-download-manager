import { useEffect, useMemo, useState } from 'react';
import { describeFormat, formatBytes, formatDuration, groupQualities } from '../lib/format.js';
import { DownloadIcon, FilmIcon } from './Icons.jsx';

export default function MediaCard({ analysis, busy, onDownload }) {
  const groups = useMemo(() => groupQualities(analysis.formats), [analysis]);
  const [qualityKey, setQualityKey] = useState(groups[0]?.key);
  const [formatId, setFormatId] = useState(groups[0]?.formats[0]?.id);
  const [thumbFailed, setThumbFailed] = useState(false);

  // New analysis -> reset the selection.
  useEffect(() => {
    setQualityKey(groups[0]?.key);
    setFormatId(groups[0]?.formats[0]?.id);
    setThumbFailed(false);
  }, [groups]);

  const group = groups.find((g) => g.key === qualityKey) || groups[0];
  const selected = group?.formats.find((f) => f.id === formatId) || group?.formats[0];
  const duration = formatDuration(analysis.duration);
  const size = formatBytes(selected?.filesize);

  const pickQuality = (g) => {
    setQualityKey(g.key);
    setFormatId((g.formats.find((f) => f.ext === 'mp4') || g.formats[0]).id);
  };

  return (
    <section aria-label="Media details" className="glass animate-rise p-4 sm:p-6">
      <div className="grid gap-6 md:grid-cols-[minmax(0,19rem)_1fr]">
        <div>
          <div className="relative aspect-video overflow-hidden rounded-2xl border border-white/10 bg-ink-800">
            {analysis.thumbnail && !thumbFailed ? (
              <img
                src={analysis.thumbnail}
                alt=""
                referrerPolicy="no-referrer"
                loading="lazy"
                onError={() => setThumbFailed(true)}
                className="h-full w-full object-cover"
              />
            ) : (
              <div className="flex h-full w-full items-center justify-center text-slate-600"><FilmIcon className="h-12 w-12" /></div>
            )}
            {duration && (
              <span className="absolute bottom-2 right-2 rounded-lg bg-black/70 px-2 py-0.5 text-xs font-medium text-white backdrop-blur">
                {duration}
              </span>
            )}
          </div>
        </div>

        <div className="min-w-0">
          <h2 className="line-clamp-2 break-words text-xl font-semibold leading-snug text-white sm:text-2xl">{analysis.title}</h2>
          <dl className="mt-3 flex flex-wrap gap-x-6 gap-y-1 text-sm">
            <div className="flex gap-2"><dt className="text-slate-500">Source</dt><dd className="font-medium text-slate-200">{analysis.source}</dd></div>
            {duration && <div className="flex gap-2"><dt className="text-slate-500">Duration</dt><dd className="font-medium text-slate-200">{duration}</dd></div>}
            {size && <div className="flex gap-2"><dt className="text-slate-500">Size</dt><dd className="font-medium text-slate-200">{size}</dd></div>}
          </dl>

          <div className="mt-6 space-y-5">
            <fieldset>
              <legend className="mb-2 text-sm font-medium text-slate-400">Quality</legend>
              <div className="flex flex-wrap gap-2">
                {groups.map((g) => (
                  <button key={g.key} type="button" className="chip" aria-pressed={g.key === group.key} disabled={busy} onClick={() => pickQuality(g)}>
                    {g.label}
                  </button>
                ))}
              </div>
            </fieldset>

            <fieldset>
              <legend className="mb-2 text-sm font-medium text-slate-400">Format</legend>
              <div className="flex flex-wrap gap-2">
                {group.formats.map((f) => (
                  <button key={f.id} type="button" className="chip" aria-pressed={f.id === selected.id} disabled={busy} onClick={() => setFormatId(f.id)}>
                    {f.ext === 'auto' ? 'Auto' : f.ext.toUpperCase()}
                  </button>
                ))}
              </div>
            </fieldset>
          </div>

          {analysis.note && <p className="mt-4 rounded-xl border border-amber-300/20 bg-amber-300/5 px-3 py-2 text-sm text-amber-200">{analysis.note}</p>}

          <button
            type="button"
            disabled={busy || !selected}
            onClick={() => onDownload({
              url: analysis.url, formatId: selected.id, title: analysis.title,
              source: analysis.source, formatLabel: describeFormat(selected),
            })}
            className="btn-primary mt-6 h-14 w-full sm:w-auto sm:min-w-[14rem]"
          >
            <DownloadIcon />
            Download
          </button>
        </div>
      </div>
    </section>
  );
}
