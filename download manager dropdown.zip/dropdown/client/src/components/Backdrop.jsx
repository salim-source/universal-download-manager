export default function Backdrop() {
  return (
    <div aria-hidden="true" className="pointer-events-none fixed inset-0 z-0 overflow-hidden">
      <div className="absolute -left-40 -top-40 h-[28rem] w-[28rem] animate-drift rounded-full bg-accent-teal/20 blur-[120px]" />
      <div className="absolute -right-32 top-1/4 h-[30rem] w-[30rem] animate-drift rounded-full bg-accent-violet/20 blur-[130px] [animation-delay:-6s]" />
      <div className="absolute -bottom-48 left-1/3 h-[26rem] w-[26rem] animate-drift rounded-full bg-accent-blue/15 blur-[120px] [animation-delay:-12s]" />
      <div
        className="absolute inset-0 opacity-[0.35]"
        style={{
          backgroundImage:
            'linear-gradient(rgba(255,255,255,.04) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.04) 1px, transparent 1px)',
          backgroundSize: '56px 56px',
          maskImage: 'radial-gradient(ellipse at 50% 20%, black 20%, transparent 70%)',
          WebkitMaskImage: 'radial-gradient(ellipse at 50% 20%, black 20%, transparent 70%)',
        }}
      />
    </div>
  );
}
