import { useCallback, useEffect, useRef, useState } from 'react';
import * as api from '../lib/api.js';

const sleep = (ms) => new Promise((r) => { setTimeout(r, ms); });
export const BUSY_PHASES = ['analyzing', 'fetching', 'downloading', 'preparing'];

/**
 * phase: idle | analyzing | ready | fetching | downloading | preparing | completed | failed
 */
export default function useDownloader({ onCompleted } = {}) {
  const [phase, setPhase] = useState('idle');
  const [analysis, setAnalysis] = useState(null);
  const [error, setError] = useState(null);
  const [progress, setProgress] = useState(null);
  const run = useRef(0);          // bumping this cancels any running loop
  const jobId = useRef(null);
  const phaseRef = useRef('idle');
  const onCompletedRef = useRef(onCompleted);
  onCompletedRef.current = onCompleted;

  const move = useCallback((next) => { phaseRef.current = next; setPhase(next); }, []);

  useEffect(() => () => { run.current += 1; }, []);

  const fail = useCallback((err) => {
    setError({ message: err.message || 'Something went wrong. Please try again.', code: err.code, stage: phaseRef.current });
    setProgress(null);
    move('failed');
  }, [move]);

  const analyze = useCallback(async (url) => {
    const id = ++run.current;
    setError(null); setAnalysis(null); setProgress(null);
    move('analyzing');
    try {
      const data = await api.analyze(url);
      if (run.current !== id) return;
      setAnalysis(data);
      move('ready');
    } catch (err) {
      if (run.current === id) fail(err);
    }
  }, [fail, move]);

  const download = useCallback(async ({ url, formatId, title, source, formatLabel }) => {
    const id = ++run.current;
    setError(null); setProgress({ percent: null });
    move('fetching');
    try {
      const { jobId: newId } = await api.startDownload(url, formatId);
      jobId.current = newId;
      let failures = 0;
      for (;;) {
        if (run.current !== id) return;
        let job;
        try {
          job = await api.getJob(newId);
          failures = 0;
        } catch (err) {
          if (run.current !== id) return;
          failures += 1;
          if (failures >= 4 || err.code === 'JOB_NOT_FOUND') throw err;
          await sleep(1000);
          continue;
        }
        if (run.current !== id) return;

        if (job.status === 'failed') throw new api.ApiError(job.error?.message || 'The download failed.', job.error?.code);
        if (job.status === 'cancelled') return;
        if (job.status === 'completed') break;

        move(job.status === 'downloading' ? 'downloading' : job.status === 'processing' ? 'preparing' : 'fetching');
        setProgress({
          percent: job.percent, speed: job.speed, eta: job.eta, part: job.part, parts: job.parts,
          downloadedBytes: job.downloadedBytes, totalBytes: job.totalBytes,
        });
        await sleep(700);
      }

      move('preparing');
      setProgress({ percent: 100 });
      const link = document.createElement('a');
      link.href = api.fileUrl(newId);
      link.rel = 'noopener';
      link.style.display = 'none';
      document.body.appendChild(link);
      link.click();
      link.remove();
      onCompletedRef.current?.({ url, formatId, title, source, formatLabel });
      await sleep(600);
      if (run.current !== id) return;
      move('completed');
    } catch (err) {
      if (run.current === id) fail(err);
    }
  }, [fail, move]);

  const cancel = useCallback(() => {
    run.current += 1;
    if (jobId.current) api.cancelJob(jobId.current).catch(() => {});
    jobId.current = null;
    setProgress(null);
    setError(null);
    move(analysis ? 'ready' : 'idle');
  }, [analysis, move]);

  const dismiss = useCallback(() => {
    setError(null); setProgress(null);
    move(analysis ? 'ready' : 'idle');
  }, [analysis, move]);

  return { phase, analysis, error, progress, busy: BUSY_PHASES.includes(phase), analyze, download, cancel, dismiss };
}
