import { useCallback, useState } from 'react';
import { loadHistory, saveHistory } from '../lib/history.js';

export default function useHistory() {
  const [items, setItems] = useState(loadHistory);

  const add = useCallback((entry) => {
    setItems((prev) => {
      const next = [entry, ...prev.filter((p) => !(p.url === entry.url && p.formatId === entry.formatId))].slice(0, 50);
      saveHistory(next);
      return next;
    });
  }, []);

  const remove = useCallback((id) => {
    setItems((prev) => {
      const next = prev.filter((p) => p.id !== id);
      saveHistory(next);
      return next;
    });
  }, []);

  const clear = useCallback(() => {
    saveHistory([]);
    setItems([]);
  }, []);

  return { items, add, remove, clear };
}
