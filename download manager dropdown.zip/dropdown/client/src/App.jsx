import Backdrop from './components/Backdrop.jsx';
import Header from './components/Header.jsx';
import Footer from './components/Footer.jsx';
import Home from './pages/Home.jsx';

export default function App() {
  return (
    <div className="relative min-h-screen overflow-x-hidden">
      <Backdrop />
      <div className="relative z-10 mx-auto flex min-h-screen w-full max-w-5xl flex-col px-4 sm:px-6">
        <Header />
        <main className="flex-1">
          <Home />
        </main>
        <Footer />
      </div>
    </div>
  );
}
