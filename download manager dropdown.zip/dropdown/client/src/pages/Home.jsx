import { useCallback } from 'react';
import History from '../components/History.jsx';
import MediaCard from '../components/MediaCard.jsx';
import ProgressCard from '../components/ProgressCard.jsx';
import UrlForm from '../components/UrlForm.jsx';
import useDownloader from '../hooks/useDownloader.js';
import useHistory from '../hooks/useHistory.js';
import { makeEntry } from '../lib/history.js';

export default function Home() {
  const history = useHistory();
  const onCompleted = useCallback((info) => history.add(makeEntry(info)), [history.add]); // eslint-disable-line react-hooks/exhaustive-deps
  const dl = useDownloader({ onCompleted });

  const showProgress = ['analyzing', 'fetching', 'downloading', 'preparing', 'completed', 'failed'].includes(dl.phase);
  const downloading = ['fetching', 'downloading', 'preparing'].includes(dl.phase);

  return (
    <div className="space-y-8 pb-6 sm:space-y-10">
      <section className="animate-rise pt-4 text-center sm:pt-10">
        <p className="text-gradient text-base font-semibold sm:text-lg">Paste. Choose. Download.</p>
        <h1 className="mt-3 text-4xl font-extrabold tracking-tight text-white sm:text-6xl">Download your media</h1>
        <p className="mx-auto mt-4 max-w-xl text-base text-slate-400 sm:text-lg">
          Paste a public video or media URL and choose an available format.
        </p>
      </section>

      <UrlForm onAnalyze={dl.analyze} busy={dl.busy} analyzing={dl.phase === 'analyzing'} />

      {showProgress && (
        <ProgressCard phase={dl.phase} progress={dl.progress} error={dl.error} onCancel={dl.cancel} onDismiss={dl.dismiss} />
      )}

      {dl.analysis && dl.phase !== 'analyzing' && (
        <MediaCard key={dl.analysis.url} analysis={dl.analysis} busy={downloading} onDownload={dl.download} />
      )}

      <History
        items={history.items}
        busy={dl.busy}
        onAgain={(item) => dl.download({ url: item.url, formatId: item.formatId, title: item.title, source: item.source, formatLabel: item.formatLabel })}
        onRemove={history.remove}
        onClear={history.clear}
      />
    </div>
  );
}
