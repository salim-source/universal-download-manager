import react from '@vitejs/plugin-react';
import { defineConfig } from 'vite';

// In development, requests to /api are forwarded to the Express server on port 4000.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/api': { target: 'http://127.0.0.1:4000', changeOrigin: true },
    },
  },
});
