/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['"Segoe UI Variable Display"', '"SF Pro Display"', 'Inter', 'ui-sans-serif', 'system-ui', '-apple-system', '"Segoe UI"', 'Roboto', 'sans-serif'],
      },
      colors: {
        ink: { 950: '#06070f', 900: '#0b0d1a', 800: '#12152a' },
        accent: { teal: '#5eead4', blue: '#60a5fa', violet: '#a78bfa' },
      },
      boxShadow: {
        glass: '0 10px 40px -10px rgba(0,0,0,0.6), inset 0 1px 0 0 rgba(255,255,255,0.06)',
        glow: '0 0 40px -6px rgba(96,165,250,0.55)',
      },
      keyframes: {
        rise: { from: { opacity: 0, transform: 'translateY(14px)' }, to: { opacity: 1, transform: 'translateY(0)' } },
        drift: { '0%,100%': { transform: 'translate3d(0,0,0)' }, '50%': { transform: 'translate3d(30px,-24px,0)' } },
        sheen: { from: { backgroundPosition: '200% 0' }, to: { backgroundPosition: '-200% 0' } },
        slide: { from: { transform: 'translateX(-100%)' }, to: { transform: 'translateX(350%)' } },
      },
      animation: {
        rise: 'rise .6s cubic-bezier(.2,.7,.2,1) both',
        drift: 'drift 18s ease-in-out infinite',
        sheen: 'sheen 2.4s linear infinite',
        slide: 'slide 1.4s ease-in-out infinite',
      },
    },
  },
  plugins: [],
};
